/* THIS FILE WILL BE OVERWRITTEN BY DEV-C++ */
/* DO NOT EDIT ! */

#ifndef MYHOOK_PRIVATE_H
#define MYHOOK_PRIVATE_H

/* VERSION DEFINITIONS */
#define VER_STRING	"1.2.3.9"
#define VER_MAJOR	1
#define VER_MINOR	2
#define VER_RELEASE	3
#define VER_BUILD	9
#define COMPANY_NAME	"SourceForge"
#define FILE_VERSION	""
#define FILE_DESCRIPTION	"Low Resource Key Logger"
#define INTERNAL_NAME	""
#define LEGAL_COPYRIGHT	"GPL 3.0"
#define LEGAL_TRADEMARKS	""
#define ORIGINAL_FILENAME	""
#define PRODUCT_NAME	"MyHook"
#define PRODUCT_VERSION	"1.2"

#endif /*MYHOOK_PRIVATE_H*/
